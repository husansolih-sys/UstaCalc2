# UstaCalc Retsept — Android

Android WebView wrapper for the original UstaCalc recipe/cost calculator HTML.

## Build
- JDK 17
- Android SDK Platform 35
- Gradle 8.7
- Android Gradle Plugin 8.6.1

Run: `gradle assembleDebug`
APK: `app/build/outputs/apk/debug/app-debug.apk`

The calculator content is in `app/src/main/assets/index.html`.
